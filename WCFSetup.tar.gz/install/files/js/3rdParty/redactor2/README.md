About Redactor II
-----------------

Redactor II is a WYSIWYG-editor created by Imperavi LLC., Copyright (c) 2009-2016. You can make use of Redactor II in any plugin or app for WSC 3.0 free of charge. You are not allowed to extract or re-use the editor (in entirety or in potions) for any other use unless you own a license for Redactor II.

Please see http://imperavi.com/redactor/license/ for more information.

Redactor II is **NOT** free software!
