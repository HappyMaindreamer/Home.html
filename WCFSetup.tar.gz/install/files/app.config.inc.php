<?php
// com.woltlab.wcf (packageID 0 during WCFSetup)
if (!defined('WCF_DIR')) define('WCF_DIR', __DIR__.'/');
if (!defined('PACKAGE_ID')) define('PACKAGE_ID', 0);
